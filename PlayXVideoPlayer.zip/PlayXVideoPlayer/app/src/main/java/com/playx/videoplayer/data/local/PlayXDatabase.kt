package com.playx.videoplayer.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        FavoriteEntity::class,
        RecentlyPlayedEntity::class,
        HiddenVideoEntity::class,
        PlaylistEntity::class,
        PlaylistItemEntity::class,
        HiddenFolderPinEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class PlayXDatabase : RoomDatabase() {
    abstract fun favoriteDao(): FavoriteDao
    abstract fun recentlyPlayedDao(): RecentlyPlayedDao
    abstract fun hiddenVideoDao(): HiddenVideoDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun hiddenFolderPinDao(): HiddenFolderPinDao

    companion object {
        @Volatile private var INSTANCE: PlayXDatabase? = null

        fun getInstance(context: Context): PlayXDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    PlayXDatabase::class.java,
                    "playx.db",
                ).build().also { INSTANCE = it }
            }
    }
}
