package com.playx.videoplayer.ui.screens.player

import android.app.Activity
import android.media.AudioManager
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView
import com.playx.videoplayer.data.model.Video
import com.playx.videoplayer.viewmodel.PlayerViewModel
import kotlin.math.abs

/**
 * Full-screen player. Gesture zones (matching Mi Video conventions):
 *  - Left half vertical drag  -> screen brightness
 *  - Right half vertical drag -> media volume
 *  - Double tap left/right    -> seek -/+ 10s
 *  - Double tap center        -> play/pause
 *  - Pinch                    -> zoom / fit / crop scale of the video surface
 */
@Composable
fun PlayerScreen(
    video: Video,
    viewModel: PlayerViewModel,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val view = LocalView.current
    val state by viewModel.state.collectAsState()

    var controlsVisible by remember { mutableStateOf(true) }
    var videoScale by remember { mutableStateOf(1f) }
    var brightness by remember { mutableStateOf(0.5f) }
    var volumeFraction by remember { mutableStateOf(0.5f) }
    var gestureHintText by remember { mutableStateOf<String?>(null) }

    val audioManager = remember { context.getSystemService(android.content.Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }

    LaunchedEffect(Unit) {
        viewModel.initPlayer(context)
        viewModel.play(video)
        volumeFraction = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume
    }

    // Keep screen on during playback.
    DisposableEffect(Unit) {
        val activity = context as? Activity
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            viewModel.savePlaybackProgress()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { controlsVisible = !controlsVisible },
                    onDoubleTap = { offset ->
                        val third = size.width / 3f
                        when {
                            offset.x < third -> { viewModel.seekBy(-10_000); gestureHintText = "-10s" }
                            offset.x > third * 2 -> { viewModel.seekBy(10_000); gestureHintText = "+10s" }
                            else -> viewModel.togglePlayPause()
                        }
                    },
                )
            }
            .pointerInput(Unit) {
                detectTransformGestures { _, _, zoom, _ ->
                    videoScale = (videoScale * zoom).coerceIn(1f, 3f)
                }
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures { change, dragAmount ->
                    val isLeftHalf = change.position.x < size.width / 2f
                    val delta = -dragAmount / size.height
                    if (isLeftHalf) {
                        brightness = (brightness + delta).coerceIn(0f, 1f)
                        val layoutParams = (context as? Activity)?.window?.attributes
                        layoutParams?.screenBrightness = brightness
                        (context as? Activity)?.window?.attributes = layoutParams
                        gestureHintText = "Brightness ${(brightness * 100).toInt()}%"
                    } else {
                        volumeFraction = (volumeFraction + delta).coerceIn(0f, 1f)
                        audioManager.setStreamVolume(
                            AudioManager.STREAM_MUSIC,
                            (volumeFraction * maxVolume).toInt(),
                            0,
                        )
                        gestureHintText = "Volume ${(volumeFraction * 100).toInt()}%"
                    }
                }
            },
    ) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    useController = false
                    player = viewModel.exoPlayer
                }
            },
            update = { it.player = viewModel.exoPlayer; it.scaleX = videoScale; it.scaleY = videoScale },
            modifier = Modifier.fillMaxSize(),
        )

        if (state.isBuffering) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center), color = Color.White)
        }

        gestureHintText?.let { hint ->
            LaunchedEffect(hint) {
                kotlinx.coroutines.delay(700)
                gestureHintText = null
            }
            Surface(
                color = Color.Black.copy(alpha = 0.6f),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.align(Alignment.Center).padding(16.dp),
            ) {
                Text(hint, color = Color.White, modifier = Modifier.padding(12.dp))
            }
        }

        if (controlsVisible) {
            PlayerControlsOverlay(
                title = state.videoTitle,
                isPlaying = state.isPlaying,
                currentMs = state.currentPositionMs,
                durationMs = state.durationMs,
                speed = state.playbackSpeed,
                onBack = onBack,
                onPlayPause = viewModel::togglePlayPause,
                onSeek = viewModel::seekTo,
                onSpeedClick = viewModel::cyclePlaybackSpeed,
            )
        }
    }
}

@Composable
private fun PlayerControlsOverlay(
    title: String,
    isPlaying: Boolean,
    currentMs: Long,
    durationMs: Long,
    speed: Float,
    onBack: () -> Unit,
    onPlayPause: () -> Unit,
    onSeek: (Long) -> Unit,
    onSpeedClick: () -> Unit,
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.5f))
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text(title, color = Color.White, maxLines = 1, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.weight(1f))

        // Bottom controls
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.5f))
                .padding(12.dp),
        ) {
            Slider(
                value = if (durationMs > 0) currentMs.toFloat() / durationMs else 0f,
                onValueChange = { onSeek((it * durationMs).toLong()) },
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(formatTime(currentMs), color = Color.White, style = MaterialTheme.typography.labelSmall)

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { onSeek((currentMs - 10_000).coerceAtLeast(0)) }) {
                        Icon(Icons.Default.Replay10, contentDescription = "Rewind", tint = Color.White)
                    }
                    IconButton(onClick = onPlayPause) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = Color.White,
                            modifier = Modifier.size(36.dp),
                        )
                    }
                    IconButton(onClick = { onSeek(currentMs + 10_000) }) {
                        Icon(Icons.Default.Forward10, contentDescription = "Forward", tint = Color.White)
                    }
                    TextButton(onClick = onSpeedClick) {
                        Text("${speed}x", color = Color.White)
                    }
                }

                Text(formatTime(durationMs), color = Color.White, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSeconds = ms / 1000
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
