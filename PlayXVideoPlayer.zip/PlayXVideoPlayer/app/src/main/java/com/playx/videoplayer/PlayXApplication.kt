package com.playx.videoplayer

import android.app.Application
import com.playx.videoplayer.data.local.PlayXDatabase
import com.playx.videoplayer.data.repository.VideoRepository

class PlayXApplication : Application() {

    lateinit var repository: VideoRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val db = PlayXDatabase.getInstance(this)
        repository = VideoRepository(this, db)
    }
}
