package com.playx.videoplayer.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.playx.videoplayer.data.repository.VideoRepository
import com.playx.videoplayer.ui.screens.home.HomeScreen
import com.playx.videoplayer.ui.screens.player.PlayerScreen
import com.playx.videoplayer.viewmodel.HomeViewModel
import com.playx.videoplayer.viewmodel.PlayerViewModel
import com.playx.videoplayer.viewmodel.ViewModelFactory

private object Routes {
    const val HOME = "home"
    const val PLAYER = "player/{videoId}"
    fun player(videoId: Long) = "player/$videoId"
}

@Composable
fun PlayXNavHost(repository: VideoRepository) {
    val navController = rememberNavController()
    val factory = remember { ViewModelFactory(repository) }
    val homeViewModel: HomeViewModel = viewModel(factory = factory)

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                viewModel = homeViewModel,
                onVideoClick = { video -> navController.navigate(Routes.player(video.id)) },
            )
        }
        composable(
            route = Routes.PLAYER,
            arguments = listOf(navArgument("videoId") { type = NavType.LongType }),
        ) { backStackEntry ->
            val videoId = backStackEntry.arguments?.getLong("videoId") ?: -1L
            val video = homeViewModel.state.value.allVideos.find { it.id == videoId }
            val playerViewModel: PlayerViewModel = viewModel(factory = factory)
            if (video != null) {
                PlayerScreen(
                    video = video,
                    viewModel = playerViewModel,
                    onBack = { navController.popBackStack() },
                )
            }
        }
    }
}
