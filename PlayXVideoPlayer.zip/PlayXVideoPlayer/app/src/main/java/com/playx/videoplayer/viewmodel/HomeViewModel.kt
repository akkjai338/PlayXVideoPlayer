package com.playx.videoplayer.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.playx.videoplayer.data.local.RecentlyPlayedEntity
import com.playx.videoplayer.data.model.Video
import com.playx.videoplayer.data.model.VideoFolder
import com.playx.videoplayer.data.repository.VideoRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class HomeTab { RECENT, ALL, FOLDERS, FAVORITES, HIDDEN }

data class HomeUiState(
    val isLoading: Boolean = true,
    val isRefreshing: Boolean = false,
    val allVideos: List<Video> = emptyList(),
    val searchQuery: String = "",
    val selectedTab: HomeTab = HomeTab.ALL,
    val favoriteIds: Set<Long> = emptySet(),
    val hiddenIds: Set<Long> = emptySet(),
    val recentlyPlayed: List<RecentlyPlayedEntity> = emptyList(),
    val folders: List<VideoFolder> = emptyList(),
) {
    /** Videos for the currently selected tab, filtered by search query, excluding hidden
     * (except on the Hidden tab itself). */
    val visibleVideos: List<Video>
        get() {
            val query = searchQuery.trim().lowercase()
            val base = when (selectedTab) {
                HomeTab.ALL -> allVideos.filterNot { it.id in hiddenIds }
                HomeTab.FAVORITES -> allVideos.filter { it.id in favoriteIds && it.id !in hiddenIds }
                HomeTab.HIDDEN -> allVideos.filter { it.id in hiddenIds }
                HomeTab.RECENT -> {
                    val order = recentlyPlayed.associate { it.videoId to it.lastPlayedAt }
                    allVideos.filter { it.id in order.keys && it.id !in hiddenIds }
                        .sortedByDescending { order[it.id] }
                }
                HomeTab.FOLDERS -> allVideos.filterNot { it.id in hiddenIds }
            }
            return if (query.isEmpty()) base
            else base.filter { it.displayName.lowercase().contains(query) }
        }
}

class HomeViewModel(private val repository: VideoRepository) : ViewModel() {

    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()

    init {
        loadVideos(initial = true)
        observeLocalState()
    }

    private fun observeLocalState() {
        viewModelScope.launch {
            repository.observeFavoriteIds().collect { ids ->
                _state.update { it.copy(favoriteIds = ids) }
            }
        }
        viewModelScope.launch {
            repository.observeHiddenIds().collect { ids ->
                _state.update { it.copy(hiddenIds = ids) }
            }
        }
        viewModelScope.launch {
            repository.observeRecentlyPlayed().collect { recent ->
                _state.update { it.copy(recentlyPlayed = recent) }
            }
        }
    }

    fun loadVideos(initial: Boolean = false) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = initial, isRefreshing = !initial) }
            val videos = repository.scanAllVideos()
            val folders = repository.groupByFolder(videos)
            _state.update {
                it.copy(allVideos = videos, folders = folders, isLoading = false, isRefreshing = false)
            }
        }
    }

    fun onSearchQueryChange(query: String) {
        _state.update { it.copy(searchQuery = query) }
    }

    fun onTabSelected(tab: HomeTab) {
        _state.update { it.copy(selectedTab = tab) }
    }

    fun toggleFavorite(videoId: Long) {
        viewModelScope.launch { repository.toggleFavorite(videoId) }
    }

    fun setHidden(videoId: Long, hidden: Boolean) {
        viewModelScope.launch { repository.setHidden(videoId, hidden) }
    }
}
