package com.playx.videoplayer.data.repository

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import com.playx.videoplayer.data.local.*
import com.playx.videoplayer.data.model.Video
import com.playx.videoplayer.data.model.VideoFolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Single source of truth for video data. Scans MediaStore (fast, no filesystem
 * walk needed) and layers app-local state (favorites / hidden / recently played)
 * from Room on top.
 */
class VideoRepository(
    private val context: Context,
    private val db: PlayXDatabase,
) {

    /** Full library scan. Runs on IO dispatcher; cheap enough to call on pull-to-refresh. */
    suspend fun scanAllVideos(): List<Video> = withContext(Dispatchers.IO) {
        val videos = mutableListOf<Video>()
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.MIME_TYPE,
        )

        context.contentResolver.query(
            collection,
            projection,
            null,
            null,
            "${MediaStore.Video.Media.DATE_MODIFIED} DESC",
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val widthCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
            val heightCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val path = cursor.getString(dataCol) ?: continue
                val uri = ContentUris.withAppendedId(collection, id)
                videos += Video(
                    id = id,
                    uri = uri.toString(),
                    title = cursor.getString(titleCol) ?: cursor.getString(nameCol),
                    displayName = cursor.getString(nameCol),
                    path = path,
                    folderName = File(path).parentFile?.name ?: "Unknown",
                    durationMs = cursor.getLong(durationCol),
                    sizeBytes = cursor.getLong(sizeCol),
                    width = cursor.getInt(widthCol),
                    height = cursor.getInt(heightCol),
                    dateModifiedSeconds = cursor.getLong(dateCol),
                    mimeType = cursor.getString(mimeCol) ?: "video/*",
                )
            }
        }
        videos
    }

    /** Groups a video list by parent folder for the Folder View tab. */
    fun groupByFolder(videos: List<Video>): List<VideoFolder> =
        videos.groupBy { it.folderName to File(it.path).parent.orEmpty() }
            .map { (key, group) ->
                VideoFolder(
                    folderName = key.first,
                    folderPath = key.second,
                    videoCount = group.size,
                    totalSizeBytes = group.sumOf { it.sizeBytes },
                )
            }
            .sortedBy { it.folderName.lowercase() }

    // --- Favorites ---
    fun observeFavoriteIds(): Flow<Set<Long>> =
        db.favoriteDao().observeAll().map { list -> list.map { it.videoId }.toSet() }

    suspend fun toggleFavorite(videoId: Long) {
        val isFav = db.favoriteDao().observeAll().first().any { it.videoId == videoId }
        if (isFav) db.favoriteDao().remove(videoId) else db.favoriteDao().add(FavoriteEntity(videoId))
    }

    // --- Hidden ---
    fun observeHiddenIds(): Flow<Set<Long>> =
        db.hiddenVideoDao().observeAll().map { list -> list.map { it.videoId }.toSet() }

    suspend fun setHidden(videoId: Long, hidden: Boolean) {
        if (hidden) db.hiddenVideoDao().add(HiddenVideoEntity(videoId)) else db.hiddenVideoDao().remove(videoId)
    }

    // --- Recently played / resume position ---
    fun observeRecentlyPlayed(): Flow<List<RecentlyPlayedEntity>> = db.recentlyPlayedDao().observeAll()

    suspend fun recordPlayback(videoId: Long, positionMs: Long, durationMs: Long) {
        db.recentlyPlayedDao().upsert(
            RecentlyPlayedEntity(
                videoId = videoId,
                lastPlayedAt = System.currentTimeMillis(),
                lastPositionMs = positionMs,
                durationMs = durationMs,
            )
        )
    }

    suspend fun getResumePosition(videoId: Long): Long =
        db.recentlyPlayedDao().get(videoId)?.lastPositionMs ?: 0L
}
