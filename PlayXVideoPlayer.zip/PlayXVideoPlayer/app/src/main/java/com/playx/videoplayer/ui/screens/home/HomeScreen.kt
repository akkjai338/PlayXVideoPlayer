package com.playx.videoplayer.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.playx.videoplayer.data.model.Video
import com.playx.videoplayer.ui.components.VideoCard
import com.playx.videoplayer.viewmodel.HomeTab
import com.playx.videoplayer.viewmodel.HomeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onVideoClick: (Video) -> Unit,
) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        topBar = {
            Column {
                TopAppBar(title = { Text("PlayX") })
                OutlinedTextField(
                    value = state.searchQuery,
                    onValueChange = viewModel::onSearchQueryChange,
                    placeholder = { Text("Search videos") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                )
                ScrollableTabs(state.selectedTab, viewModel::onTabSelected)
            }
        },
    ) { padding ->
        PullToRefreshBox(
            isRefreshing = state.isRefreshing,
            onRefresh = { viewModel.loadVideos() },
            modifier = Modifier.fillMaxSize().padding(padding),
        ) {
            when {
                state.isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                state.visibleVideos.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(emptyMessageFor(state.selectedTab))
                }
                else -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 160.dp),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(state.visibleVideos, key = { it.id }) { video ->
                        VideoCard(
                            video = video,
                            isFavorite = video.id in state.favoriteIds,
                            onClick = { onVideoClick(video) },
                            onLongClick = { viewModel.setHidden(video.id, video.id !in state.hiddenIds) },
                            onFavoriteClick = { viewModel.toggleFavorite(video.id) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ScrollableTabs(selected: HomeTab, onSelect: (HomeTab) -> Unit) {
    val tabs = listOf(
        HomeTab.RECENT to "Recent",
        HomeTab.ALL to "All Videos",
        HomeTab.FOLDERS to "Folders",
        HomeTab.FAVORITES to "Favorites",
        HomeTab.HIDDEN to "Hidden",
    )
    ScrollableTabRow(selectedTabIndex = tabs.indexOfFirst { it.first == selected }.coerceAtLeast(0)) {
        tabs.forEach { (tab, label) ->
            Tab(selected = tab == selected, onClick = { onSelect(tab) }, text = { Text(label) })
        }
    }
}

private fun emptyMessageFor(tab: HomeTab): String = when (tab) {
    HomeTab.RECENT -> "No recently played videos yet"
    HomeTab.ALL -> "No videos found on this device"
    HomeTab.FOLDERS -> "No folders found"
    HomeTab.FAVORITES -> "No favorites yet — tap the heart on a video to add one"
    HomeTab.HIDDEN -> "No hidden videos"
}
