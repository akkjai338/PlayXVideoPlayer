package com.playx.videoplayer.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.playx.videoplayer.data.model.Video
import com.playx.videoplayer.data.repository.VideoRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PlayerUiState(
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = true,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val playbackSpeed: Float = 1f,
    val videoTitle: String = "",
    val error: String? = null,
)

private val SPEED_OPTIONS = listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f)

class PlayerViewModel(private val repository: VideoRepository) : ViewModel() {

    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    var exoPlayer: ExoPlayer? = null
        private set

    private var currentVideoId: Long = -1L
    private var progressJob: Boolean = false

    fun initPlayer(context: Context) {
        if (exoPlayer != null) return
        val player = ExoPlayer.Builder(context)
            .setHandleAudioBecomingNoisy(true)
            .build()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _state.update { it.copy(isPlaying = isPlaying) }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                _state.update {
                    it.copy(
                        isBuffering = playbackState == Player.STATE_BUFFERING,
                        durationMs = player.duration.coerceAtLeast(0L),
                    )
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                _state.update { it.copy(error = error.message) }
            }
        })
        exoPlayer = player
        startProgressLoop()
    }

    /** Plays a video, resuming from last saved position if available. */
    fun play(video: Video) {
        currentVideoId = video.id
        _state.update { it.copy(videoTitle = video.title) }
        viewModelScope.launch {
            val resumeMs = repository.getResumePosition(video.id)
            val mediaItem = MediaItem.fromUri(video.uri)
            exoPlayer?.apply {
                setMediaItem(mediaItem, resumeMs)
                prepare()
                playWhenReady = true
            }
        }
    }

    private fun startProgressLoop() {
        if (progressJob) return
        progressJob = true
        viewModelScope.launch {
            while (true) {
                exoPlayer?.let { p ->
                    _state.update { it.copy(currentPositionMs = p.currentPosition) }
                }
                delay(500)
            }
        }
    }

    fun togglePlayPause() {
        exoPlayer?.let { if (it.isPlaying) it.pause() else it.play() }
    }

    fun seekTo(positionMs: Long) {
        exoPlayer?.seekTo(positionMs.coerceIn(0, exoPlayer?.duration ?: 0))
    }

    fun seekBy(deltaMs: Long) {
        exoPlayer?.let { seekTo(it.currentPosition + deltaMs) }
    }

    fun cyclePlaybackSpeed() {
        val current = _state.value.playbackSpeed
        val next = SPEED_OPTIONS[(SPEED_OPTIONS.indexOf(current) + 1) % SPEED_OPTIONS.size]
        setPlaybackSpeed(next)
    }

    fun setPlaybackSpeed(speed: Float) {
        exoPlayer?.setPlaybackSpeed(speed)
        _state.update { it.copy(playbackSpeed = speed) }
    }

    /** Call from onPause/onStop so resume position + recently-played is persisted. */
    fun savePlaybackProgress() {
        val player = exoPlayer ?: return
        if (currentVideoId < 0) return
        viewModelScope.launch {
            repository.recordPlayback(currentVideoId, player.currentPosition, player.duration.coerceAtLeast(0))
        }
    }

    override fun onCleared() {
        savePlaybackProgress()
        exoPlayer?.release()
        exoPlayer = null
        super.onCleared()
    }
}
