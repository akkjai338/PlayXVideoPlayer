package com.playx.videoplayer.data.model

/**
 * Core domain model for a video file, hydrated from MediaStore.
 * [id] is the MediaStore content id, used as the stable key across the app
 * (favorites, recently played, hidden, playlists all reference it).
 */
data class Video(
    val id: Long,
    val uri: String,
    val title: String,
    val displayName: String,
    val path: String,
    val folderName: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val width: Int,
    val height: Int,
    val dateModifiedSeconds: Long,
    val mimeType: String,
) {
    val resolutionLabel: String
        get() = when {
            height >= 2160 -> "4K"
            height >= 1440 -> "2K"
            height >= 1080 -> "1080p"
            height >= 720 -> "720p"
            height >= 480 -> "480p"
            height >= 360 -> "360p"
            else -> "240p"
        }
}

/** UI-friendly grouping of videos by folder. */
data class VideoFolder(
    val folderName: String,
    val folderPath: String,
    val videoCount: Int,
    val totalSizeBytes: Long,
)
