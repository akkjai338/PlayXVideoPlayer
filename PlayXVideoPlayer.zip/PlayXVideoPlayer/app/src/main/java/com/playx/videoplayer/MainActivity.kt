package com.playx.videoplayer

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.playx.videoplayer.ui.PlayXNavHost
import com.playx.videoplayer.ui.theme.PlayXTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = (application as PlayXApplication).repository

        setContent {
            PlayXTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    VideoPermissionGate {
                        PlayXNavHost(repository = repository)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
private fun VideoPermissionGate(content: @Composable () -> Unit) {
    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_VIDEO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    val permissionState = rememberPermissionState(permission)

    if (permissionState.status.isGranted) {
        content()
    } else {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            PermissionRequestBody(onRequest = { permissionState.launchPermissionRequest() })
        }
    }
}

@Composable
private fun PermissionRequestBody(onRequest: () -> Unit) {
    androidx.compose.runtime.LaunchedEffect(Unit) { onRequest() }
    Text("PlayX needs storage access to find videos on your device.", style = MaterialTheme.typography.bodyLarge)
}
