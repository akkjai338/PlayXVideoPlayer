package com.playx.videoplayer.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PlayXPurple = Color(0xFF7C5CFF)
private val PlayXPurpleDark = Color(0xFF5B3FD6)
private val PlayXBackground = Color(0xFF0E0E12)
private val PlayXSurface = Color(0xFF17171E)

private val DarkColors = darkColorScheme(
    primary = PlayXPurple,
    secondary = PlayXPurpleDark,
    background = PlayXBackground,
    surface = PlayXSurface,
    onPrimary = Color.White,
    onBackground = Color(0xFFEDEDF2),
    onSurface = Color(0xFFEDEDF2),
)

private val LightColors = lightColorScheme(
    primary = PlayXPurple,
    secondary = PlayXPurpleDark,
    background = Color(0xFFFAFAFC),
    surface = Color.White,
)

@Composable
fun PlayXTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = MaterialTheme.typography,
        content = content,
    )
}
