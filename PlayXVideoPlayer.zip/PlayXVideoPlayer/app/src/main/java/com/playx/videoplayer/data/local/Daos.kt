package com.playx.videoplayer.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites ORDER BY addedAt DESC")
    fun observeAll(): Flow<List<FavoriteEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE videoId = :videoId)")
    fun isFavorite(videoId: Long): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun add(entity: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE videoId = :videoId")
    suspend fun remove(videoId: Long)
}

@Dao
interface RecentlyPlayedDao {
    @Query("SELECT * FROM recently_played ORDER BY lastPlayedAt DESC LIMIT 50")
    fun observeAll(): Flow<List<RecentlyPlayedEntity>>

    @Query("SELECT * FROM recently_played WHERE videoId = :videoId LIMIT 1")
    suspend fun get(videoId: Long): RecentlyPlayedEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: RecentlyPlayedEntity)
}

@Dao
interface HiddenVideoDao {
    @Query("SELECT * FROM hidden_videos")
    fun observeAll(): Flow<List<HiddenVideoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun add(entity: HiddenVideoEntity)

    @Query("DELETE FROM hidden_videos WHERE videoId = :videoId")
    suspend fun remove(videoId: Long)
}

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun observePlaylists(): Flow<List<PlaylistEntity>>

    @Insert
    suspend fun createPlaylist(entity: PlaylistEntity): Long

    @Query("DELETE FROM playlists WHERE playlistId = :playlistId")
    suspend fun deletePlaylist(playlistId: Long)

    @Query("SELECT * FROM playlist_items WHERE playlistId = :playlistId ORDER BY position ASC")
    fun observeItems(playlistId: Long): Flow<List<PlaylistItemEntity>>

    @Insert
    suspend fun addItem(item: PlaylistItemEntity)

    @Query("DELETE FROM playlist_items WHERE itemId = :itemId")
    suspend fun removeItem(itemId: Long)
}

@Dao
interface HiddenFolderPinDao {
    @Query("SELECT * FROM hidden_folder_pin WHERE id = 0 LIMIT 1")
    suspend fun get(): HiddenFolderPinEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun set(entity: HiddenFolderPinEntity)
}
