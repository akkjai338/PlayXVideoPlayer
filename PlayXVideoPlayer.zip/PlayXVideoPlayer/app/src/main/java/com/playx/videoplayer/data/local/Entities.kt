package com.playx.videoplayer.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/** videoId here is the MediaStore id from [com.playx.videoplayer.data.model.Video]. */

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val videoId: Long,
    val addedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "recently_played")
data class RecentlyPlayedEntity(
    @PrimaryKey val videoId: Long,
    val lastPlayedAt: Long,
    val lastPositionMs: Long,
    val durationMs: Long,
)

@Entity(tableName = "hidden_videos")
data class HiddenVideoEntity(
    @PrimaryKey val videoId: Long,
    val hiddenAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val playlistId: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "playlist_items")
data class PlaylistItemEntity(
    @PrimaryKey(autoGenerate = true) val itemId: Long = 0,
    val playlistId: Long,
    val videoId: Long,
    val position: Int,
)

@Entity(tableName = "hidden_folder_pin")
data class HiddenFolderPinEntity(
    @PrimaryKey val id: Int = 0,
    val pinHash: String,
)
