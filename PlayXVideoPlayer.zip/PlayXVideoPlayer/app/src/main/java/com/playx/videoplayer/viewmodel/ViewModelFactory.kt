package com.playx.videoplayer.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.playx.videoplayer.data.repository.VideoRepository

/**
 * Minimal manual DI. If the project grows, swap this for Hilt —
 * the repository constructor signature is already Hilt-friendly.
 */
class ViewModelFactory(private val repository: VideoRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when (modelClass) {
            HomeViewModel::class.java -> HomeViewModel(repository) as T
            PlayerViewModel::class.java -> PlayerViewModel(repository) as T
            else -> throw IllegalArgumentException("Unknown ViewModel class: $modelClass")
        }
    }
}
